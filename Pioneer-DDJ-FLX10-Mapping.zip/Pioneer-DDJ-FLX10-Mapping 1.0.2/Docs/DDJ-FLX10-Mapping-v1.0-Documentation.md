# Pioneer DDJ-FLX10 Mapping v1.0 - Documentation Complète

## Informations Générales

- **Nom du mapping:** DDJ-FLX10 PROD
- **Version:** v1.0
- **Auteur:** Marc Zischka (Zim)
- **Compatibilité:** Mixxx 2.3.6+
- **Date de livraison:** Décembre 2024

## Fichiers du Mapping

- `Pioneer-DDJ-FLX10.midi.xml` - Configuration MIDI XML
- `Pioneer-DDJ-FLX10-scripts.js` - Script JavaScript

## Sections Implémentées

### 1. Section Mixer
- **Faders de volume (4 canaux):** Contrôle du volume avec VU meters LEDs
- **Crossfader:** Contrôle de crossfader 14-bit
- **EQ 3-bandes (Low/Medium/High):** Contrôle paramétrique 14-bit
- **Gain:** Contrôle de gain par canal
- **Filtre:** Contrôle de filtre par canal
- **PFL/Headphone:** Écoute casque par canal
- **Master:** Contrôle du gain master et crossfader

### 2. Section Transport
- **Play/Pause:** Lecture/pause par canal
- **Cue:** 
  - Normal: Retour au cue point
  - Shift: Définir cue point
- **Reverse:** Lecture inversée avec slip mode
- **Slip:** Activer/désactiver slip mode

### 3. Section Tempo
- **Faders de tempo:** Contrôle 14-bit avec plage ±16% par défaut
- **Tempo Reset:** Remise à zéro du tempo
- **Rate Range Selector:** Cycle des plages de tempo
- **Beat Sync:** Synchronisation BPM

### 4. Section Jog Wheels
- **Touch:** Activation mode scratch
- **Rotation:** 
  - Normal: Pitch bend
  - Touch: Scratch mode
- **Affichage Jog:** Informations temporelles sur les jogs

### 5. Section Hot Cues
- **8 Hot Cues par canal:** Activation et suppression
- **LEDs:** Feedback visuel des hot cues

### 6. Section Loops
- **Loop In/Out:** Définition manuelle de boucles
- **Loop Halve:** Diviser la boucle par 2 (Shift+Loop In)
- **Loop Double:** Doubler la boucle (Shift+Loop Out)
- **Auto Loop:** Boucles automatiques (2/4/8/16 beats)
- **Loop Exit:** Sortie de boucle

### 7. Section Beat Jump
- **Forward/Backward:** Sauts de beats par défaut
- **Shift:** Sauts de 32 beats (flèches CUE/LOOP CALL)

### 8. Section Key/Tonalité
- **Key Sync:** Synchronisation de tonalité (Mixxx 2.3+)
- **Key Reset:** Remise à zéro de la tonalité

### 9. Section Samplers
- **8 Samplers:** Lecture/arrêt, sync, PFL
- **Controls:** Start/stop, BPM sync, cue goto

### 10. Section Effects
- **Effect Unit 1-4:** Contrôle d'effets
- **Beat FX:** Sélection et activation d'effets
- **Group Enable:** Activation par canal/headphone

### 11. Section Navigation
- **Browse Knob:** Navigation dans la bibliothèque
- **Load Track:** Chargement de piste par canal
- **Move Focus:** Navigation gauche/droite

### 12. Section Display/UI
- **Time Display:** Basculer temps écoulé/restant
- **Show Waveforms:** Afficher/cacher les waveforms
- **Show Mixer:** Afficher/cacher le mixer
- **Show 4 Decks:** Afficher 4 decks
- **Show Samplers:** Afficher/cacher les samplers
- **Show Effects:** Afficher/cacher les effets
- **Show Microphone:** Afficher/cacher le micro

## Fonctionnalités Spéciales

### Shift Button
- **Double-click:** Détecté mais désactivé (300ms)
- **LEDs:** Mise à jour des LEDs lors de l'activation
- **Fonctions modifiées:** Plusieurs contrôles changent de comportement

### LEDs et Feedback Visuel
- **Play/Cue:** Clignotement natif Mixxx
- **Hot Cues:** Feedback d'activation
- **PFL:** Indicateur d'écoute casque
- **Keylock:** Indicateur de verrouillage de tonalité
- **Quantize:** Indicateur de quantification
- **Reverse:** Indicateur de lecture inversée
- **Sync Key:** Feedback de synchro tonalité
- **Volume VU Meters:** LEDs des faders de volume (0xB0-0xB3, control 0x02)

### Initialisation
- **Rate Range:** ±16% par défaut au démarrage
- **LEDs:** Initialisation des feedbacks visuels
- **Affichages:** Mise à jour des displays

## Contrôles par Canal (Channel 1-4)

### Boutons principaux
- `0x0B` - Play/Pause
- `0x0C` - Cue最后一次
- `0x10` - Loop In
- `0x11` - Loop Out
- `0x15` - Reverse
- `0x35` - Quantize
- `0x40` - Slip
- `0x41` - Tempo Reset
- `0x46` - Rate Reset (script)
- `0x54` - PFL
- `0x58` - Sync Enabled
- `0x60` - Rate Range Selector (script)
- `0x64` - Key Reset
- `0x65` - Key Sync
- `0x66` - Beat Sync
- `0x70` - Rewind
- `0x71` - Forward

### Faders et Knobs
- `0x00` - Tempo Fader MSB (script)
- `0x04` - Pregain
- `0x0F` - EQ Low
- `0x0B` - EQ Medium
- `0x07` - EQ High
- `0x13` - Volume Fader
- `0x20` - Tempo Fader LSB (script)

### Jog Wheel
- `0x36` - Jog Touch (script)
- `0x21` - Jog Turn Pitch Bend (script)
- `0x22` - Jog Turn Scratch (script)

### Hot Cues (0x00-0x07)
- `0x97/0x98` - Channel 1 (Activate/Clear)
- `0x99/0x9A` - Channel 2 (Activate/Clear)
- `0x9B/0x9C` - Channel 3 (Activate/Clear)
- `0x9D/0x9E` - Channel 4 (Activate/Clear)

## Master Controls

### Boutons
- `0x4B` - Shift Handler (script)
- `0x65/0x7A` - Navigation bibliothèque

### Faders
- `0x08` - Master Gain
- `0x1F/0x3F` - Crossfader (MSB/LSB)
- `0x0C` - Headphone Mix
- `0x0D` - Headphone Gain
- `0x40` - Browse Knob

## Samplers (1-8)

### Controls
- `0x30-0x37` - Cue Gotoandplay
- `0x3C-0x3F` - Start/Stop
- `0x70-0x73` - Beat Sync
- `0x74-0x77` - PFL

## Fonctions JavaScript Whitelist

Seules ces fonctions JS conservent `script-binding` dans le XML:

1. `LoopDoubleShift` - Loop double avec shift
2. `LoopHalveShift` - Loop halve avec shift
3. `RangeSelector` - Sélecteur de plage de tempo
4. `TimeTypeChange` - Changement type d'affichage temps
5. `cueButton` - Gestion bouton cue
6. `rate_lsb` - Tempo fader LSB
7. `rate_msb` - Tempo fader MSB
8. `rate_reset` - Reset tempo
9. `reverse` - Reverse avec slip
10. `shiftHandler` - Gestion bouton shift
11. `wheelTouch` - Touch jog wheel
12. `wheelTurn` - Rotation jog wheel

## Corrections v1.0

### Corrections critiques appliquées:
- **Key Sync:** Remplacé `key_sync` par `sync_key` (Mixxx 2.3+)
- **Tempo 14-bit:** MSB/LSB correctement mappés avec script-binding
- **Rate Range:** Initialisation à ±16% dans `init()`
- **LEDs Volume:** Outputs XML ajoutés pour VU meters
- **Conflits JS/XML:** Suppression des fonctions JS dupliquées

### Fonctions JS supprimées (utilisent XML natif):
- `loopIn`, `loopOut` → XML `loop_in`, `loop_out`
- `browseNavigation` → XML `MoveFocusBackward/Forward`
- `reloop` → XML `reloop_exit`
- `autoLoop` → XML `beatloop_X_enabled`
- `sync` → XML `beatsync`
- `playPause` → XML `play`
- `syncKey` → XML `sync_key`

## Tests et Validation

### Tests à effectuer:
1. **Fonctionnement de base:** Play, cue, volume, EQ
2. **Tempo:** Faders 14-bit, reset, range selector
3. **Key Sync:** Synchronisation de tonalité
4. **LEDs:** Play/Cue clignotement, VU meters volume
5. **Jog Wheels:** Scratch et pitch bend
6. **Loops:** Auto loops, manual loops, halve/double
7. **Hot Cues:** 8 hot cues par canal
8. **Effects:** Activation et contrôle
9. **Samplers:** Lecture et sync
10. **Navigation:** Bibliothèque et chargement

### Validation finale:
- Tous les contrôles XML natifs fonctionnent
- Fonctions JS whitelistées opérationnelles
- LEDs et feedback visuel corrects
- Pas de conflits MIDI
- Performance stable

## Notes Techniques

### Architecture:
- **1 MIDI message ↔ 1 contrôle Mixxx** (principe strict)
- **XML:** Contrôles natifs Mixxx
- **JS:** Logique complexe uniquement
- **LEDs:** XML outputs pour feedback automatique

### Performance:
- **Optimisé:** Minimum de traitement JS
- **Réactif:** Contrôles XML directs
- **Stable:** Pas de boucles ou timers

### Compatibilité:
- **Mixxx 2.3.6+:** Contrôles `sync_key` supportés
- **DDJ-FLX10:** Mapping complet du hardware
- **4 Decks:** Support complet des 4 canaux

---

**Status:** Prêt pour livraison et test final  
**Version:** 1.0 Production  
**Date:** 21 Décembre 2024
