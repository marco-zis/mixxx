# DDJ-FLX10 · Mapping Mixxx 2.3 (v1.0)

## Fonctions principales
- Play / Cue (Cue avec SHIFT = cue_set)
- Sync & Key Sync (key_sync natif)
- Beatjump par deck (CH1–CH4) ± via midino 0x19/0x1A
- Loop In / Out, loop_halve / loop_double (SHIFT)
- Reverse : slip momentané (appui), toggle reverse (SHIFT)
- Tempo fader 14‑bit (MSB 0x00 / LSB 0x20, status 0xB0–0xB3) + rateRange init ±16 %
- Jog / Scratch (wheelTouch / wheelTurn)
- Hotcues 1‑8 par deck
- RangeSelector (cycle des plages)
- TimeTypeChange (elapsed / remaining)
- VU meters faders (LED 0xB0–0xB3, ctrl 0x02)
- Play / Cue / Quantize / Reverse / Keylock / PFL / Sync_key LEDs via outputs XML

## Points de design
- Règle 1 MIDI ↔ 1 contrôle natif en priorité
- JS limité aux logiques : SHIFT, jog/scratch, 14‑bit tempo, reverse slip/toggle, range/time, cueButton
- Key Sync : protégé SHIFT dans le code, mais mappé en natif (normal) pour l’activation

## Vérifications rapides (tests)
- Tempo : course complète, sens correct, rateRange ajustable (Shift+Tempo Reset côté contrôleur)
- Key Sync : alignement tonalité ok
- LEDs : faders inactifs éteints, Play/Cue clignotements natifs actifs
- Jog/scratch : touch + turn OK
- Loops : In/Out, halve/double (SHIFT) OK

## Résumé / portée
Ce document décrit le mapping Pioneer **DDJ‑FLX10** pour **Mixxx 2.3.x**.
Architecture : **XML = 1 message MIDI → 1 contrôle Mixxx**, **JS = logique avancée** (SHIFT/modes, jog/scratch, 14-bit, comportements Pioneer).

## Quick Start
1. Ouvrez **Preferences → Controllers → Pioneer DDJ‑FLX10** et chargez le mapping.
2. Vérifiez **Key Sync** : le bouton mappe `sync_key` (CH1..CH4) en `<normal/>`.
3. Vérifiez **Tempo 14‑bit** : présence de `rate_msb`/`rate_lsb` par deck (CH1=0xB0 … CH4=0xB3).
4. (Option) Ajustez `rateRange` dans `init` (±16% ou ±50%).

## Fonctions & mappages clés
- **Key Sync** : `sync_key` (Mixxx 2.3), 1 entrée XML par deck (pas de handler JS).
- **Tempo faders** : `rate_msb` + `rate_lsb` (14‑bit) sur le même status CC par deck.
- **CUE** : appui = `cue_default`, **SHIFT** = `cue_set` (via `cueButton` JS).
- **Jog/Scratch** : `scratchEnable` / `scratchTick` en JS, pitch bend hors scratch.
- **Pad modes** : Hotcue / Loop / Sampler (XML) ; bascule & états complexes en JS.
- **LEDs** : priorité aux `<output>` XML ; JS seulement pour multi‑états non natifs.

## Troubleshooting
- **Key Sync ne répond pas** : s'assurer que la clé est `sync_key` (et non `key_sync`) et en `<normal/>` (pas de `<script-binding>`).
- **Course de fader très faible** : vérifier la présence des deux contrôles `rate_msb` et `rate_lsb` sur le même status CC (0xB0..0xB3).
- **LEDs incohérentes** : éviter de piloter en JS une LED déjà gérée par `<output>` XML.
- **Collisions MIDI** : une même paire `(status, midino)` ne doit piloter qu’une action.

## Changelog
- **v1.0** : Base stable (Key Sync natif, faders 14‑bit, zéro collision).  
- **v1.1 (prévu)** : Range selector cyclique, pad modes clarifiés, LEDs multi‑états propres.
