# Checklist tests – Version Prod A (DDJ-FLX10 · Mixxx 2.3+)

## Pré-requis
- Mixxx 2.3+ lancé, mapping `Pioneer-DDJ-FLX10.midi.xml` (Prod A) chargé.
- Contrôleur DDJ-FLX10 connecté (USB) et alimenté.
- Aucune autre sortie MIDI vers le contrôleur (éviter la pollution).
- Gain/trim neutres, faders de volume au minimum, crossfader centré.

## Tests essentiels (stabilité prioritaire)
- **Play / Cue (fonction)** : Lecture/pause et cue fonctionnent sur CH1–CH4. (LEDs play/cue non pilotées en Prod A pour éviter le spam.)
- **Jogs** : Touch capacitive OK (scratch) et roue en mode bend OK, sans latence ni sauts.
- **Tempo fader 14‑bit** : Course complète exploitée, sens correct, retour stable dans Mixxx. RateRange ajustable via Shift+Tempo Reset si prévu côté contrôleur.
- **Key Sync (natif)** : Bouton Key Sync (0x65) active la sync de tonalité par deck, pas d’effet si SHIFT maintenu (protection JS). Feedback LED `sync_key` OK, pas de double mapping.
- **Shift** : Modifieur global fiable (pas de collage). Vérifier les combos SHIFT + boutons sensibles (loop halve/double, tempo reset/range).
- **Reverse / Slip Reverse** : Bouton reverse via `reverseHandler` : slip momentané (maintien) et toggle (appui bref) selon design, sans conflit LED.
- **Looping** : Loop In/Out, Reloop/Exit natifs OK. Loop Halve / Loop Double (midi 0x4C/0x4D) OK et réactifs.
- **Beatjump** : Avant/arrière par deck (statuts 0x90..0x93) OK et sans doublons.
- **Hotcues** : Déclenchement/suppression OK (si définis dans cette version).
- **Sampler/FX Pads** : Vérifier qu’aucun conflit de mode (si utilisés en Prod A).

## LEDs & pollution
- **Vu-mètres faders verticaux** : LEDs suivent le niveau audio sur CH1–CH4.
- **Keylock / Quantize / Reverse / Sync_key** : Feedbacks présents et stables, pas de clignotement parasite.
- **Play/Cue LEDs** : Doivent rester silencieuses (outputs retirés) → aucune pollution sur 0x0B/0x0C.
- **Autres LEDs connues** : Pas de spam MIDI sur 0x5B, 0x10/0x11, 0x0B/0x0C.

## Sanity checks techniques
- Aucun « collision MIDI » signalé au chargement (log Mixxx).
- Lints XML/JS propres, pas d’erreur au démarrage du script.
- Pas de latence ou dropouts audibles pendant jog/tempo/loop.

## Si un test échoue
- Noter le deck, le bouton/LED, le code MIDI observé (status/midino) et le contexte (SHIFT oui/non).
- Préciser si le problème est fonctionnel (contrôle) ou visuel (LED/pollution).

