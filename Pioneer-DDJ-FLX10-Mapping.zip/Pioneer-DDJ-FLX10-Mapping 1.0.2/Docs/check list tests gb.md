# CHECK LIST TESTS - DDJ-FLX10 PROD v1.0
# Version de référence stable - Tests sur contrôleur réel

## CONFIGURATION TEST
- [ ] Mixxx 2.3.6+ démarré
- [ ] Mapping DDJ-FLX10 PROD v1.0 chargé
- [ ] Contrôleur DDJ-FLX10 connecté et reconnu
- [ ] Aucune erreur dans la console MIDI

## SECTION MIXER
- [ ] Crossfader fonctionnel (centre = silencieux)
- [ ] Gain Master ajustable
- [ ] EQ 3-bandes fonctionnelles (LOW/MID/HIGH)
- [ ] PFL/Cue headphone fonctionnel (4 canaux)
- [ ] HeadMix/Split fonctionnels

## SECTION DECKS (x4)
### Lecture
- [ ] Play/Pause fonctionne (0x0B)
- [ ] CUE simple fonctionne (0x0C)
- [ ] CUE + SHIFT = Set Cue point
- [ ] Load track fonctionne
- [ ] Time display change (0x3E)

### Tempo
- [ ] Tempo fader 14-bit fonctionnel (MSB 0x00 + LSB 0x20)
- [ ] Tempo range selector fonctionne (0x60)
- [ ] Tempo reset fonctionne (0x41)
- [ ] Beat Sync fonctionne (0x66)
- [ ] Reverse toggle fonctionne (0x15)

### Jog Wheels
- [ ] Jog Touch détecté (0x36)
- [ ] Pitch bend normal (0x21)
- [ ] Scratch mode actif (0x22)
- [ ] Scratch sensible et précis

### Hotcues (8 par deck)
- [ ] Hotcue 1-8 activate (0x97-0x9E + 0x00-0x07)
- [ ] Hotcue 1-8 clear (Shift + activate)
- [ ] LEDs hotcues réactifs

### Loop
- [ ] Loop In/Out fonctionne (0x10/0x11)
- [ ] Loop Halve (Shift + Loop In)
- [ ] Loop Double (Shift + Loop Out)

### Beatjump
- [ ] Beatjump backward (0x19)
- [ ] Beatjump forward (0x1A)
- [ ] Taille de saut configurable

### Key
- [ ] Key reset fonctionne (0x64)
- [ ] Key sync natif fonctionne (0x65)
- [ ] Keylock toggle fonctionne

### Modes
- [ ] Slip toggle fonctionne (0x40)
- [ ] Quantize toggle fonctionne (Shift + CUE)

## SECTION EFFETS
- [ ] FX1-3 Enable/Disable (0x50-0x52)
- [ ] FX assignment par deck fonctionne
- [ ] Wet/Dry mix fonctionnel
- [ ] BeatFX selector fonctionne

## SECTION SAMPLERS
- [ ] Sampler 1-8 Play/Stop
- [ ] Sampler load fonctionne
- [ ] Sampler PFL fonctionne
- [ ] Sampler sync fonctionne

## SECTION BROWSE
- [ ] Browser knob navigation (0x40)
- [ ] Load selected track
- [ ] Focus navigation (0x65/0x7A)

## SECTION SHIFT
- [ ] Shift master fonctionne (0x4B)
- [ ] Shift par deck fonctionne (0x3F)
- [ ] Combos SHIFT + boutons fonctionnels

## VALIDATION TECHNIQUE
- [ ] 0 collisions MIDI détect Pony
- [ ] Tempo 14-bit natif XML (pas de handler JS)
- [ ] Key sync natif XML (pas de handler JS)
- [ ] LEDs stabilisées (pas de clignotement excessif)
- [ ] Messages MIDI cohérents

## PERFORMANCE
- [ ] Latence acceptable (< 10ms)
- [ ] Réactivité des jog wheels
- [ ] Stabilité sur longue durée
- [ ] Consommation CPU raisonnable

## RAPPORT DE TEST
Date : ____________
Heure : ____________
Testeur : __________
Version Mixxx : __________

**Statut global** : [ ] PASS [ ] FAIL

**Issues identifiées** :
1. _________________________
2. _________________________
3. _________________________

**Recommandations** :
__________________________________________________

**Signature** : ____________
